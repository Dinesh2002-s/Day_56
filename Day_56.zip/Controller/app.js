// const express = require('express');
// const fs = require('fs');

// const app = express();
// const port = 3000;

// app.get('/getAllRestaurants', async (req, res) => {

//   fs.readFile('restaurant.json',  (err, data) => {
//     if (err) {
//       console.error(err);
//       res.status(500).send('Error reading the file');
//       return;
//     }
//     const restaurant = JSON.parse(data);
//     res.json(restaurant);
//   });
// });

// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });

// const express = require('express');
// const fs = require('fs');

// const app = express();
// const port = 3500;

// app.get('/getAllLocations', async (req, res) => {

//   fs.readFile('locations.json',  (err, data) => {
//     if (err) {
//       console.error(err);
//       res.status(500).send('Error reading the file');
//       return;
//     }
//     const locations = JSON.parse(data);
//     res.json(locations);
//   });
// });

// app.listen(port, () => {
//   console.log(`Server is running on port ${port}`);
// });

// const express = require('express');
// const fs = require('fs');

// const app = express();
// const port = 3900;

// app.get('/getAllMealTypes', async (req, res) => {

//   fs.readFile('MealTypes.json',  (err, data) => {
//     if (err) {
//       console.error(err);
//       res.status(500).send('Error reading the file');
//       return;
//     }
//     const MealTypes = JSON.parse(data);
//     res.json(MealTypes);
//   });
// });

// app.listen(port, () => {
//   console.log(`MealTypes is running on port ${port}`);
// });



// let restaurantData;
// try {
//   restaurantData = JSON.parse(fs.readFileSync('restaurant.json'));
// } catch (error) {
//   console.error('Error reading restaurant data:', error);
//   process.exit(1);
// }

const express = require('express');

const app = express();
const port = 8900;



app.get('/getRestaurants/:city', async(req, res) => {
  const restaurantData = require("./restaurant.json")
  let city = req.params.city;
  try {
    const filteredRestaurants = restaurantData.filter(restaurant => restaurant?.city === city);
    res.json(filteredRestaurants);
  } catch (error) {
    console.error('Error filtering restaurants:', error);
    res.send(error)
  }
});
app.post("/post",(req,res)=>{
  try{
    res.send("message : Data Posted Successfully")
  }catch(err){
    res.send(err)
  }
})
app.listen(port, () => {
  console.log(`Server is running on ${port}`);
});




